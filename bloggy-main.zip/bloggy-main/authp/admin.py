from django.contrib import admin
from authp.models import Use
# Register your models here.
admin.site.register(Use)